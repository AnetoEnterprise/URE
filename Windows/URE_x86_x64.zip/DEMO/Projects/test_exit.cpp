#include "test.h"
#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <iostream>


using namespace std;











class TESTLib : public TEST {
public:string CFExec(string request, string goWeb, int goresponse){
string resultat="quitter";

return resultat;
}
};



extern "C" TESTLib* create(){
return new TESTLib;
}

extern "C" void destroy(TESTLib* Tl){
delete Tl;
}
