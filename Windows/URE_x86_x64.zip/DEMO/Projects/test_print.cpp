#include "test.h"
#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <iostream>
#include <fstream>
#include <vector>

#include <boost/algorithm/string.hpp>
#include <boost/lexical_cast.hpp>


using namespace std;

string lineLang="";
string file="";









//Début Replace
string goReplace(string data, string from, string to){
size_t ReplaceDetect=data.find(from);
if(ReplaceDetect!=string::npos){
size_t start_pos = 0;
while((start_pos = data.find(from, start_pos)) != std::string::npos) {
data.replace(start_pos, from.length(), to);
start_pos += to.length(); // Handles case where 'to' is a substring of 'from'
}
}
return data;
}
//Fin Replace



//Début Response LANG
string goResponseLANG(string myGetPosition){
string myLang="";
ifstream goLoadUserLang("/usr/share/test/lang.conf", ios::binary);
if (goLoadUserLang.is_open()){
while(getline(goLoadUserLang, lineLang)){
if(lineLang=="" || lineLang=="-;"){}else{
size_t DetectLANG=lineLang.find(":" + myGetPosition + ":");
if(DetectLANG!=string::npos){
lineLang=goReplace(lineLang, ":EE:", "\n");
lineLang=goReplace(lineLang, ":" + myGetPosition + ":", "");
lineLang=goReplace(lineLang, ":A1:", "\x1B[32m");
lineLang=goReplace(lineLang, ":A2:", "\033[0m");
lineLang=goReplace(lineLang, ":B1:", "\x1B[31m");
myLang=lineLang;
goLoadUserLang.close();
}}}
goLoadUserLang.close();
}else{
myLang="    ->Lecture des réponses impossible (LANG).\n    ->";
}

return myLang;
}
//Fin response LANG











class TESTLib : public TEST {
public:string CFExec(string request, string goWeb, int goresponse){
string resultat="";
string GetedScriptFile="";
string GetedSyntaxes="";
string GetedData="";

size_t DetectPV=request.find(";");
if(DetectPV!=string::npos){
vector<string> dataToPV;
boost::split(dataToPV, request, boost::is_any_of(";"));
GetedScriptFile=dataToPV[0];
GetedSyntaxes=dataToPV[1];

//Begin to verify syntaxes
size_t DetectEQ=request.find("=");
if(DetectEQ!=string::npos){
vector<string> dataToEQ;
boost::split(dataToEQ, GetedSyntaxes, boost::is_any_of("="));
GetedData=dataToEQ[1];
GetedData=goReplace(GetedData, "`", "");
GetedData=goReplace(GetedData, "\"", "");
resultat=GetedData + "\n";

}else{
resultat=goResponseLANG("1");
resultat=goReplace(resultat, ":E1:", "" + GetedSyntaxes + "");
resultat=goReplace(resultat, ":E2:", "" + GetedScriptFile + "");
}
//Ended to verify syntaxes

}else{
resultat=goResponseLANG("0");
}

return resultat;
}
};



extern "C" TESTLib* create(){
return new TESTLib;
}

extern "C" void destroy(TESTLib* Tl){
delete Tl;
}
