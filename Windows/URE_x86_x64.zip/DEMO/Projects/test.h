#ifndef TEST_H
#define TEST_H

#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <iostream>

using namespace std;

class TEST{
public:virtual string CFExec(string request, string goweb, int goresponse)=0;
};

#endif
